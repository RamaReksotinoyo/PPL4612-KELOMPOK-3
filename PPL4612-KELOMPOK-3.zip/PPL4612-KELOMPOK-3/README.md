# PPL4612-KELOMPOK-3
Tugas mata kuliah Proyek Perangkat Lunak
1. Muhammad Aris Setiawan (A11.2018.11575) - Business & System Analyst
2. Faizuna Rifqy (A11.2018.11038) - UI Designer
3. Frans Antoni Nugroho (A11.2018.11059) - Database Designer
4. Anugrah Tri Ramadhan (A11.2018.11540) - Project Leader, Back-End Programmer
5. Benny Wibijanto Alan Sarajar (A11.2018.11189) - Front-End Programmer
